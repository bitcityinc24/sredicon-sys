<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>CitiLights - Grid Property - With Sidebar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="shortcut icon" href="images/icon/favicon.jpg" type="image/x-icon">

  <!-- GOOGLE WEB FONTS INCLUDE -->
  <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,300italic,400italic' rel='stylesheet' type='text/css'>

  <!-- STYLESHEETS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-theme.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/jquery.nouislider.min.css">

  <!-- THEME STYLESHEETS -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/shortcode.css">
  <link rel="stylesheet" href="css/citilights-shortcode.css">
  <link rel="stylesheet" href="css/color/color1.css">
  
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<body class="page-right-sidebar">
  <!-- START SITE -->
  <div class="site">
    <!-- START HEADER -->
    <header class="noo-header">
      <!-- START TOP HEADER -->
      <div class="top-header">
        <div class="container">
          <div class="top-header-inner">
            <ul class="social-top">
              <li><a href="#" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#" title="Pinterest" target="_blank"><i class="fa fa-pinterest"></i></a></li>
              <li><a href="#" title="RSS" target="_blank"><i class="fa fa-rss"></i></a></li>
            </ul>

            <div class="top-header-content">
              <div class="emailto content-item">
                <a href="mailto:info@citilights.com"><i class="fa fa-envelope-o"></i>&nbsp;Email:info@citilights.com</a>
              </div>
              <div class="register content-item">
                <a href="login-register.html"><i class="fa fa-key"></i>&nbsp;Register</a>
              </div>
              <div class="login content-item">
                <a href="login-register.html"><i class="fa fa-sign-in"></i>&nbsp;Login</a>
              </div>
              <!-- <div class="logout content-item">
                <a href="#"><i class="fa fa-sign-out"></i>&nbsp;Logout</a>
              </div> -->
              <div class="header-search">
                <label for="input-header-search"><i class="fa fa-search"></i></label>
                <input type="text" id="input-header-search" placeholder="Search">
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- END TOP HEADER -->

      <!-- START MAIN NAVIGATION WRAP -->
      <div class="main-nav-wrap container">
        <!-- START NAVBAR TOGGLE & LOGO -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="logo">
            <div class="logo-image">
              <a href="index.html" title="NooTheme CitiLights"></a>
            </div>
          </div>
        </div>
        <!-- END NAVBAR TOGGLE & LOGO -->

        <!-- START CALLING INFO -->
        <div class="calling-info">
          <div class="calling-content">
            <i class="fa fa-mobile"></i>
            <div class="calling-desc">
              CALL  US  NOW<br>
              <span><a href="tel:(+01)-793-7938">(+01)-793-7938</a></span>
            </div>
          </div>
        </div>
        <!-- END CALLING INFO -->

        <!-- START MAIN NAVIGATION -->
        <div class="main-navigation">
          <nav class="collapse navbar-collapse" id="main-collapse" role="navigation">
            <ul class="nav navbar-nav">
              <li class="dropdown">
                <a href="/sr">Home&nbsp;<span class="caret"></span></a>
                <!-- <ul class="dropdown-menu">
                  <li><a href="home-map-vertical.html">Home Map Vertical</a></li>
                  <li><a href="home-map-horizontal.html">Home Map Horizontal</a></li>
                </ul> -->
              </li>
              <li class="dropdown">
                <a href="grid-with-sidebar.php">Properties&nbsp;<span class="caret"></span></a>
                <!--<ul class="dropdown-menu">
                  <li class="dropdown-submenu">
                    <a href="#">List</a>
                    <ul class="dropdown-menu">
                      <li><a href="list-with-sidebar.html">With Sidebar</a></li>
                      <li><a href="list-no-sidebar.html">No Sidebar</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu">
                    <a href="#">Grid</a>
                    <ul class="dropdown-menu">
                      <li><a href="grid-with-sidebar.html">With Sidebar</a></li>
                      <li><a href="grid-no-sidebar.html">No Sidebar</a></li>
                    </ul>
                  </li>
                  <li><a href="property-details.html">Property details</a></li>
                </ul>-->
              </li>
              <li class="dropdown">
                <a href="#">Features&nbsp;<span class="caret"></span></a>
                <ul class="dropdown-menu dropdown-menu-right">
                  <li class="dropdown-submenu">
                    <a href="#">Blog</a>
                    <ul class="dropdown-menu dropdown-menu-right">
                      <li><a href="blog.html">Blog</a></li>
                      <li><a href="default-blog-left-sidebar.html">Default Blog Left Sidebar</a></li>
                      <li><a href="default-blog-right-sidebar.html">Default Blog Right Sidebar</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu">
                    <a href="#">Shortcodes</a>
                    <ul class="dropdown-menu dropdown-menu-right">
                      <li><a href="shortcodes.html">Shortcodes</a></li>
                      <li><a href="citilights-shortcode.html">Citilights Shortcode</a></li>
                      <li><a href="pricing-table.html">Pricing Table</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#">Agents&nbsp;<span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="agents-listing.html">Agents Listing</a></li>
                  <li><a href="agents-detail.html">Agents Detail</a></li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#">Submit&nbsp;<span class="caret"></span></a>
                <ul class="dropdown-menu dropdown-menu-right">
                  <li><a href="my-profile.html">My Profile</a></li>
                  <li><a href="my-properties.html">My Properties</a></li>
                  <li><a href="submit-proprety.html">Submit Proprety</a></li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="contact.html">Contact&nbsp;<span class="caret"></span></a>
                <ul class="dropdown-menu dropdown-menu-right">
                  <li><a href="contact1.html">Contact 1</a></li>
                </ul>
              </li>
            </ul>
          </nav>
        </div>
        <!-- END MAIN NAVIGATION -->
      </div>
      <!-- END MAIN NAVIGATION WRAP -->
    </header>
    <!-- END HEADER -->

    <!-- START NOO WRAPPER -->
		<div class="noo-wrapper">
		  <!-- START MAINBODY -->
		  <div class="container noo-mainbody">
		  	<div class="noo-mainbody-inner">
		  		<div class="row clearfix">
				  	<!-- START MAIN CONTENT -->
				  	<div class="noo-content col-xs-12 col-md-8">
							<div class="recent-properties">
								<div class="properties grid">
	                <!-- START PROPERTIES HEADER -->
				  				<div class="properties-header">
										<h1 class="page-title">Properties</h1>
										<div class="properties-toolbar">
											<a class="selected" href="grid-with-sidebar.html" data-toggle="tooltip" data-placement="bottom" title="Grid"><i class="fa fa-th-large"></i></a>
											<a href="list-with-sidebar.html" data-toggle="tooltip" data-placement="bottom" title="List"><i class="fa fa-list"></i></a>
                      <form class="properties-ordering" method="get">
                        <div class="properties-ordering-label">Sorted by</div>
                        <div class="form-group properties-ordering-select">
                          <div class="label-select">
                            <select class="form-control">
                              <option>Date</option>
                              <option>Bath</option>
                              <option>Bed</option>
                              <option>Area</option>
                              <option>Name</option>
                            </select>
                          </div>
                        </div>
                      </form>
										</div>
									</div>
	                <!-- END PROPERTIES HEADER -->

									<!-- START PROPERTIES CONTENT -->
                  <div class="properties-content">
                    <article class="hentry">
                      <div class="property-featured">
                        <span class="featured"><i class="fa fa-star"></i></span>
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-label">Hot</span>
                        <span class="property-category"><a href="#">Single Family Home</a></span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="Visalia, NJ 93277">Visalia, NJ 93277</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>This 4 bedroom home sits on an oversized lot at the end of a cul-de-sac...</p>
                          <p class="property-fullwidth-excerpt">This 4 bedroom home sits on an oversized lot at the end of a cul-de-sac in an established neighborhood. It is in need of work...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>1913 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>2</span>
                            </div>
                            <div class="bedrooms">
                              <span>4</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span>
                                <span class="amount">&#36;154,500</span>
                              </span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;154,500</span> </span>
                            </div>
                            <div class="size"><span>1913 sqft</span></div>
                            <div class="bathrooms"><span>2</span></div>
                            <div class="bedrooms"><span>4</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-label">Hot</span>
                        <span class="property-category"><a href="#">Apartment</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="The Helux">The Helux</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>Located on 43rd Street between 10th and 11th Avenue in the hot Midtown West neighborhood...</p>
                          <p class="property-fullwidth-excerpt">Located on 43rd Street between 10th and 11th Avenue in the hot Midtown West neighborhood of Hell?s Kitchen is The Helux. These no-fee apartments feature...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>762 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>3</span>
                            </div>
                            <div class="bedrooms">
                              <span>3</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span>
                                <span class="amount">&#36;3,515</span>
                              </span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;3,515</span> /month</span>
                            </div>
                            <div class="size"><span>762 sqft</span></div>
                            <div class="bathrooms"><span>3</span></div>
                            <div class="bedrooms"><span>4</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-category"><a href="#">Single Family Home</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="Single Family Residential, NJ">Single Family Residential, NJ</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>Classic 60's ranch living. House has hardwood floors and hard coat plaster walls and ceilings...</p>
                          <p class="property-fullwidth-excerpt">Classic 60's ranch living. House has hardwood floors and hard coat plaster walls and ceilings in good condition. Intimate backyard for private gatherings. Full basement...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>1118 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>2</span>
                            </div>
                            <div class="bedrooms">
                              <span>3</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span>
                                <span class="amount">&#36;299,000</span>
                              </span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;299,000</span> </span>
                            </div>
                            <div class="size"><span>1118 sqft</span></div>
                            <div class="bathrooms"><span>2</span></div>
                            <div class="bedrooms"><span>3</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <span class="featured"><i class="fa fa-star"></i></span>
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-label sold">Sold</span>
                        <span class="property-category"><a href="#">Apartment</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="Peter Cooper Village">Peter Cooper Village</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>Peter Cooper Village/ Stuyvesant Town provides an unbeatable combination of city energy and community tranquility,...</p>
                          <p class="property-fullwidth-excerpt">Peter Cooper Village/ Stuyvesant Town provides an unbeatable combination of city energy and community tranquility, providing insulation from the city that surrounds it, yet situated...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>1304 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>2</span>
                            </div>
                            <div class="bedrooms">
                              <span>3</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span>
                                <span class="amount">&#36;5,109</span>
                              </span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;5,109</span> /month</span>
                            </div>
                            <div class="size"><span>1304 sqft</span></div>
                            <div class="bathrooms"><span>2</span></div>
                            <div class="bedrooms"><span>3</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <span class="featured"><i class="fa fa-star"></i></span>
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-category"><a href="#">Condo</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="Ocala, FL34481">Ocala, FL34481</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>Wonderful expanded end-unit Augusta featuring 2 bedrooms in split-bedroom plan, study/den/library off of cathedral-ceilinged HUGE...</p>
                          <p class="property-fullwidth-excerpt">Wonderful expanded end-unit Augusta featuring 2 bedrooms in split-bedroom plan, study/den/library off of cathedral-ceilinged HUGE living room, large dining area off of U-shaped updated kitchen,...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>1,856 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>2</span>
                            </div>
                            <div class="bedrooms">
                              <span>2</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span>
                                <span class="amount">&#36;95,000</span>
                              </span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;95,000</span> </span>
                            </div>
                            <div class="size"><span>1,856 sqft</span></div>
                            <div class="bathrooms"><span>2</span></div>
                            <div class="bedrooms"><span>2</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-label">Hot</span>
                        <span class="property-category"><a href="#">Single Family Home</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="Oakland, NJ94605">Oakland, NJ94605</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>When the sellers bought this home in 2001 they delighted in the big things: the...</p>
                          <p class="property-fullwidth-excerpt">When the sellers bought this home in 2001 they delighted in the big things: the first level “great room”, lower level “family room”, wide Bay ...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>2,568 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>2</span>
                            </div>
                            <div class="bedrooms">
                              <span>4</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span>
                                <span class="amount">&#36;335,000</span>
                              </span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;335,000</span> /month</span>
                            </div>
                            <div class="size"><span>2,568 sqft</span></div>
                            <div class="bathrooms"><span>2</span></div>
                            <div class="bedrooms"><span>4</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-category"><a href="#">Apartment</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="AVA High Line">AVA High Line</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>Special pricing for immediate move-ins! Call for details! AVA is a first. Our apartments are...</p>
                          <p class="property-fullwidth-excerpt">Special pricing for immediate move-ins! Call for details! AVA is a first. Our apartments are energized by New York City, personalized by you. Yep. Take...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>1752 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>2</span>
                            </div>
                            <div class="bedrooms">
                              <span>2</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;3,410</span> /month</span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;3,410</span> /month</span>
                            </div>
                            <div class="size"><span> 1752 sqft</span></div>
                            <div class="bathrooms"><span>2</span></div>
                            <div class="bedrooms"><span>2</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-category"><a href="#">Apartment</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="Aire">Aire</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>Situated in the highly sought-after neighborhood surrounding Lincoln Center, AIRE offers breathtaking vistas of the...</p>
                          <p class="property-fullwidth-excerpt">Situated in the highly sought-after neighborhood surrounding Lincoln Center, AIRE offers breathtaking vistas of the city skyline, Central Park and the Hudson River. Apartment features...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>531 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>3</span>
                            </div>
                            <div class="bedrooms">
                              <span>5</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;4,200</span> /month</span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;4,200</span> /month</span>
                            </div>
                            <div class="size"><span>531 sqft</span></div>
                            <div class="bathrooms"><span>3</span></div>
                            <div class="bedrooms"><span>5</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <span class="featured"><i class="fa fa-star"></i></span>
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-category"><a href="#">Condo</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="635 Staley Ave, Hayward, NJ">635 Staley Ave, Hayward, NJ</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>Corner unit! Gorgeous 3 BD / 3 BA townhome in a beautiful community. Pride of...</p>
                          <p class="property-fullwidth-excerpt">Corner unit! Gorgeous 3 BD / 3 BA townhome in a beautiful community. Pride of ownership abounds with this 3 story home with tons of...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>1516 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>3</span>
                            </div>
                            <div class="bedrooms">
                              <span>3</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;449,999</span> /month</span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;449,999</span> </span>
                            </div>
                            <div class="size"><span>1516 sqft</span></div>
                            <div class="bathrooms"><span>3</span></div>
                            <div class="bedrooms"><span>3</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-category"><a href="#">Condo</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="225 E 36th St #20D">225 E 36th St #20D</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>Turn Key sleep alcove studio in triple mint condition. Located on high floor with great...</p>
                          <p class="property-fullwidth-excerpt">Turn Key sleep alcove studio in triple mint condition. Located on high floor with great unobstructed Southern Expo. This is the perfect home for the...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>1516 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>3</span>
                            </div>
                            <div class="bedrooms">
                              <span>3</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;449,999</span> /month</span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;389,000</span> </span>
                            </div>
                            <div class="size"><span>550 sqft</span></div>
                            <div class="bathrooms"><span>1</span></div>
                            <div class="bedrooms"><span>2</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <article class="hentry">
                      <div class="property-featured">
                        <span class="featured"><i class="fa fa-star"></i></span>
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/property1.jpg" alt="">
                        </a>
                        <span class="property-label">Hot</span>
                        <span class="property-category"><a href="#">Co-op</a>
                        </span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title">
                          <a href="property-details.html" title="101 W 115th St #2B">101 W 115th St #2B</a>
                        </h2>
                        <div class="property-excerpt">
                          <p>This beautiful pre-war Co-op building situated in the heart of Harlem is 4 blocks from...</p>
                          <p class="property-fullwidth-excerpt">This beautiful pre-war Co-op building situated in the heart of Harlem is 4 blocks from Central Park and around the corner from the express 2/3...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size">
                              <span>1516 sqft</span>
                            </div>
                            <div class="bathrooms">
                              <span>3</span>
                            </div>
                            <div class="bedrooms">
                              <span>3</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;449,999</span> /month</span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details</a>
                            </div>
                          </div>
                          <div class="property-info property-fullwidth-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;439,000</span> </span>
                            </div>
                            <div class="size"><span>536 sqft</span></div>
                            <div class="bathrooms"><span>2</span></div>
                            <div class="bedrooms"><span>4</span></div>
                          </div>
                        </div>
                      </div>
                      <div class="property-action property-fullwidth-action">
                        <a href="property-details.html">More Details</a>
                      </div>
                    </article>

                    <div class="clearfix"></div>

                    <!-- START PAGINATION NAVIGATION -->
                    <nav class="pagination-nav">
                      <ul class="pagination list-center">
                        <li><a class="prev page-numbers" href="#"><i class="fa fa-angle-left"></i></a></li>
                        <li><span class="page-numbers current">1</span></li>
                        <li><a class="page-numbers" href="#">2</a></li>
                        <li><span class="page-dots"><i class="fa fa-ellipsis-h"></i></span></li>
                        <li><a class="page-numbers" href="#">7</a></li>
                        <li><a class="page-numbers" href="#">8</a></li>
                        <li><a class="next page-numbers" href="#"><i class="fa fa-angle-right"></i></a></li>
                      </ul>
                    </nav>
                    <!-- END PAGINATION NAVIGATION -->
                  </div>
                  <!-- END PROPERTIES CONTENT -->
				  			</div>							
							</div>												  		
						</div>	  		
				  	<!-- END MAIN CONTENT -->

				  	<!-- START SIDEBAR -->
				  	<div class="noo-sidebar noo-sidebar-right col-xs-12 col-md-4">
							<div class="noo-sidebar-inner">
								<!-- START FIND PROPERTY -->
							  <div class="block-sidebar find-property">
							    <h3 class="title-block-sidebar">Find Property</h3>
							    <div class="gsearch">
							  		<div class="gsearch-wrap">
							  			<form class="gsearchform" method="get" role="search">
							  				<div class="gsearch-content">
							  					<div class="gsearch-field">
							  						<div class="form-group glocation">
							  							<div class="label-select">
							  								<select class="form-control">
															    <option>All Locations</option>
															    <option>New Jersey</option>
															    <option>New York</option>
															  </select>
							  							</div>
							  						</div>

														<div class="form-group gsub-location">
															<div class="label-select">
																<select class="form-control">
														      <option>All Sub-locations</option>
														      <option>Central New York</option>
														      <option>GreenVille</option>
														      <option>Long Island</option>
														      <option>New York City</option>
														      <option>West Side</option>
														    </select>
							  							</div>
														</div>

														<div class="form-group gstatus">
							  							<div class="label-select">
																<select class="form-control">
													      <option>All Status</option>
													      <option>Open house</option>
													      <option>Rent</option>
													      <option>Sale</option>
													      <option>Sold</option>
													    </select>
							  							</div>
														</div>

														<div class="form-group gtype">
															<div class="label-select">
																<select class="form-control">
														      <option>All Type </option>
														      <option>Apartment</option>
														      <option>Co-op</option>
														      <option>Condo</option>
														      <option>Single Family Home</option>
														    </select>
							  							</div>
														</div>

														<div class="form-group gbed">
															<div class="label-select">
																<select class="form-control">
														      <option>No. of Bedrooms</option>
														      <option>1</option>
														      <option>2</option>
														      <option>3</option>
														      <option>4</option>
														      <option>5</option>
														    </select>
							  							</div>
														</div>

														<div class="form-group gbath">
															<div class="label-select">
																<select class="form-control">
														      <option>No. of Bathrooms</option>
														      <option>1</option>
														      <option>2</option>
														      <option>3</option>
														      <option>4</option>
														    </select>
							  							</div>
														</div>

														<div class="form-group gprice">
															<span class="gprice-label">Price</span>
															<div class="gslider-range gprice-slider-range"></div>
															<span class="gslider-range-value gprice-slider-range-value-min"></span>
															<span class="gslider-range-value gprice-slider-range-value-max"></span>
														</div>

														<div class="form-group garea">
															<span class="garea-label">Area</span>
															<div class="gslider-range garea-slider-range"></div>
															<span class="gslider-range-value garea-slider-range-value-min"></span>
															<span class="gslider-range-value garea-slider-range-value-max"></span>
														</div>
							  					</div>

							  					<div class="gsearch-action">
								  					<div class="gsubmit">
								  						<a class="btn btn-deault" href="#">Search Property</a>
											   		</div>
								  				</div>
							  				</div>
							  			</form>
							  		</div>
							  	</div>
							  </div>
								<!-- END FIND PROPERTY -->

							  <!-- START RECENT PROPERTY -->
							  <div class="block-sidebar recent-property">
							    <h3 class="title-block-sidebar">Recent Property</h3>
							    <div class="featured-property">
							      <ul>
							        <li>
							          <div class="featured-image">
							            <a href="property-details.html"><img src="images/property/property1.jpg" alt=""></a>
							          </div>
							          <div class="featured-decs">
							          	<span class="featured-status"><a href="#">For Sale</a></span>
							            <h4 class="featured-title"><a href="property-details.html" title="Visalia, NJ 93277">Visalia, NJ 93277</a></h4>
							          </div>
							        </li>
							        <li>
							          <div class="featured-image">
							            <a href="property-details.html"><img src="images/property/property1.jpg" alt=""></a>
							          </div>
							          <div class="featured-decs">
							          	<span class="featured-status"><a href="#">For Sale</a></span>
							            <h4 class="featured-title"><a href="property-details.html" title="Single Family Residential, NJ">Single Family Residential, NJ</a></h4>
							          </div>
							        </li>

							        <li>
							          <div class="featured-image">
							            <a href="property-details.html"><img src="images/property/property1.jpg" alt=""></a>
							          </div>
							          <div class="featured-decs">
							          	<span class="featured-status"><a href="#">For Rent</a></span>
							            <h4 class="featured-title"><a href="property-details.html" title="Peter Cooper Village">Peter Cooper Village</a></h4>
							          </div>
							        </li>
							      </ul>
							    </div>
							  </div>
							  <!-- END RECENT PROPERTY -->
							</div>
				  	</div>
				  	<!-- END SIDEBAR -->
				  </div>
		  	</div>
		  </div>
		  <!-- END MAINBODY -->
		</div>
		<!-- END NOO WRAPPER -->

    <!-- START FOOTER -->
    <footer class="footer">
      <!-- START FOOTER NAVIGATION -->
      <div class="footer-nav">
        <div class="container">
          <div class="row">
            <!-- START FOOTER ABOUT US -->
            <div class="col-xs-12 col-sm-6 col-md-3 footer-nav-col">
              <div class="ft-about-us">
                <h4 class="ft-col-title">CitiLights</h4>
                <div class="text-block">
                  <p>CitiLights brings wide range of choice, steadily updated property list and market trend for you to figure out your right decision.</p>
                  <p>You are now at right place for your real estate research.</p>
                </div>
              </div>
            </div>
            <!-- END ABOUT US -->

            <!-- START FOOTER FEATURED PROPERTIES -->
            <div class="col-xs-12 col-sm-6 col-md-3 footer-nav-col">
              <div class="ft-featured-properties">
                <h4 class="ft-col-title">Featued Property</h4>
                <div class="featured-property">
                  <ul>
                    <li>
                      <div class="featured-image">
                        <a href="property-details.html"><img src="images/property/property1.jpg" alt=""></a>
                      </div>
                      <div class="featured-decs">
                        <span class="featured-status"><a href="#"></a></span>
                        <h4 class="featured-title"><a href="property-details.html" title="Fresno, CA93722">Fresno, CA93722</a></h4>
                      </div>
                    </li>
                    <li>
                      <div class="featured-image">
                        <a href="property-details.html"><img src="images/property/property1.jpg" alt=""></a>
                      </div>
                      <div class="featured-decs">
                        <span class="featured-status"><a href="#">For Rent</a></span>
                        <h4 class="featured-title"><a href="property-details.html" title="AVA High Line">AVA High Line</a></h4>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- END FOOTER FEATURED PROPERTIES -->

            <!-- START FOOTER USEFUL LINKS -->
            <div class="col-xs-12 col-sm-6 col-md-3 footer-nav-col">
              <div class="ft-useful-links">
                <h4 class="ft-col-title">Useful links</h4>
                <nav class="useful-links-menu" role="navigation">
                  <ul>
                    <li class="menu-item"><a href="#">Terms of Use</a></li>
                    <li class="menu-item"><a href="#">Privacy Policy</a></li>
                    <li class="menu-item"><a href="#">Contact Support</a></li>
                    <li class="menu-item"><a href="#">Knowledgebase</a></li>
                    <li class="menu-item"><a href="#">Careers</a></li>
                    <li class="menu-item"><a href="#">FAQs</a></li>
                  </ul>
                </nav>
              </div>
            </div>
            <!-- END FOOTERUSEFUL LINKS  -->

            <!-- START FOOTER CONTACT INFO -->
            <div class="col-xs-12 col-sm-6 col-md-3 footer-nav-col">
              <div class="ft-contact-info">
                <h4 class="ft-col-title">Contact info</h4>
                  <ul class="detail-contact-info">
                    <li><i class="fa fa-map-marker"></i>&nbsp;376 Baker Street, New York</li>
                    <li><i class="fa fa-phone"></i>&nbsp;(+01)-486-2857</li>
                    <li><i class="fa fa-envelope-o"></i>&nbsp;<a href="mailto:info@citilights.com">info@citilights.com</a></li>
                  </ul>
              </div>
            </div>
            <!-- END FOOTER CONTACT INFO -->
          </div>
        </div>
      </div>
      <!-- END FOOTER NAVIGATION -->

      <!-- START COPYRIGHT -->
      <div class="copyright">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-sm-6 text-block">
              &copy; 2014 CitiLights. All Rights Reserved.
              <br />
              <span>Designed by <a title="Visit Nootheme.com!" href="http://www.nootheme.com/" target="_blank">NooTheme.com</a>.</span>
              <br>
            </div>
            <div class="col-xs-12 col-sm-6 logo-block">
              <div class="logo-image">
                <a href="index.html"><img src="images/logo/logo-footer.png" alt="CitiLights"></a>
              </div>
            </div>
          </div>          
        </div>
       
        <!-- START BACK TO TOP -->
        <div id="back-to-top" class="back-to-top">
          <i class="fa fa-angle-up"></i>
        </div>
        <!-- END BACK TO TOP -->
      </div>
      <!-- END COPYRIGHT -->
    </footer>
    <!-- END FOOTER -->
  </div>
  <!-- END SITE -->

  <!-- JQUERY PLUGIN -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
  <script type="text/javascript" src="js/SmoothScroll.js"></script>
  <script type="text/javascript" src="js/jquery.nouislider.all.min.js"></script>
  
  <!-- THEME SCRIPT -->
  <script type="text/javascript" src="js/script.js"></script>

</body>

</html>
