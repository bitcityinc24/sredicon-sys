<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>CitiLights - Home</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="shortcut icon" href="images/icon/favicon.jpg" type="image/x-icon">

	<!-- GOOGLE WEB FONTS INCLUDE -->
  <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,300italic,400italic' rel='stylesheet' type='text/css'>

  <!-- STYLESHEETS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-theme.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/jquery.nouislider.min.css">

  <!-- THEME STYLESHEETS -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/shortcode.css">
  <link rel="stylesheet" href="css/home.css">
  <link rel="stylesheet" href="css/citilights-shortcode.css">
  <link rel="stylesheet" href="css/color/color1.css">
  
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<body class="home page-fullwidth">
  <!-- START SITE -->
  <div class="site">
    <!-- START HEADER -->
    <header class="noo-header">
      <!-- START TOP HEADER -->
      <div class="top-header">
        <div class="container">
          <div class="top-header-inner">
            <ul class="social-top">
              <li><a href="#" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#" title="Pinterest" target="_blank"><i class="fa fa-pinterest"></i></a></li>
              <li><a href="#" title="RSS" target="_blank"><i class="fa fa-rss"></i></a></li>
            </ul>

            <div class="top-header-content">
              <div class="emailto content-item">
                <a href="mailto:info@citilights.com"><i class="fa fa-envelope-o"></i>&nbsp;Email:info@citilights.com</a>
              </div>
              <div class="register content-item">
                <a href="login-register.html"><i class="fa fa-key"></i>&nbsp;Register</a>
              </div>
              <div class="login content-item">
                <a href="login-register.html"><i class="fa fa-sign-in"></i>&nbsp;Login</a>
              </div>
              <!-- <div class="logout content-item">
                <a href="#"><i class="fa fa-sign-out"></i>&nbsp;Logout</a>
              </div> -->
              <div class="header-search">
                <label for="input-header-search"><i class="fa fa-search"></i></label>
                <input type="text" id="input-header-search" placeholder="Search">
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- END TOP HEADER -->

      <!-- START MAIN NAVIGATION WRAP -->
      <div class="main-nav-wrap container">
        <!-- START NAVBAR TOGGLE & LOGO -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="logo">
            <div class="logo-image">
              <a href="/sr" title="NooTheme CitiLights"></a>
            </div>
          </div>
        </div>
        <!-- END NAVBAR TOGGLE & LOGO -->

        <!-- START CALLING INFO -->
        <div class="calling-info">
          <div class="calling-content">
            <i class="fa fa-mobile"></i>
            <div class="calling-desc">
              CALL  US  NOW<br>
              <span><a href="tel:(+01)-793-7938">(+01)-793-7938</a></span>
            </div>
          </div>
        </div>
        <!-- END CALLING INFO -->

        <!-- START MAIN NAVIGATION -->
        <div class="main-navigation">
          <nav class="collapse navbar-collapse" id="main-collapse" role="navigation">
            <ul class="nav navbar-nav">
              <li class="dropdown active">
                <a href="index.html">Home&nbsp;<span class="caret"></span></a>
                <!-- <ul class="dropdown-menu">
                  <li><a href="home-map-vertical.html">Home Map Vertical</a></li>
                  <li><a href="home-map-horizontal.html">Home Map Horizontal</a></li>
                </ul> -->
              </li>
              <li class="dropdown">
                <a href="grid-with-sidebar.php">Properties&nbsp;<span class="caret"></span></a>
                <!--<ul class="dropdown-menu">
                  <li class="dropdown-submenu">
                    <a href="#">List</a>
                    <ul class="dropdown-menu">
                      <li><a href="list-with-sidebar.html">With Sidebar</a></li>
                      <li><a href="list-no-sidebar.html">No Sidebar</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu">
                    <a href="#">Grid</a>
                    <ul class="dropdown-menu">
                      <li><a href="grid-with-sidebar.html">With Sidebar</a></li>
                      <li><a href="grid-no-sidebar.html">No Sidebar</a></li>
                    </ul>
                  </li>
                  <li><a href="property-details.html">Property details</a></li>
                </ul>-->
              </li>
              <li class="dropdown">
                <a href="#">Features&nbsp;<span class="caret"></span></a>
                <ul class="dropdown-menu dropdown-menu-right">
                  <li class="dropdown-submenu">
                    <a href="#">Blog</a>
                    <ul class="dropdown-menu dropdown-menu-right">
                      <li><a href="blog.html">Blog</a></li>
                      <li><a href="default-blog-left-sidebar.html">Default Blog Left Sidebar</a></li>
                      <li><a href="default-blog-right-sidebar.html">Default Blog Right Sidebar</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu">
                    <a href="#">Shortcodes</a>
                    <ul class="dropdown-menu dropdown-menu-right">
                      <li><a href="shortcodes.html">Shortcodes</a></li>
                      <li><a href="citilights-shortcode.html">Citilights Shortcode</a></li>
                      <li><a href="pricing-table.html">Pricing Table</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#">Agents&nbsp;<span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="agents-listing.html">Agents Listing</a></li>
                  <li><a href="agents-detail.html">Agents Detail</a></li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#">Submit&nbsp;<span class="caret"></span></a>
                <ul class="dropdown-menu dropdown-menu-right">
                  <li><a href="my-profile.html">My Profile</a></li>
                  <li><a href="my-properties.html">My Properties</a></li>
                  <li><a href="submit-proprety.html">Submit Proprety</a></li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="contact.html">Contact&nbsp;<span class="caret"></span></a>
                <ul class="dropdown-menu dropdown-menu-right">
                  <li><a href="contact1.html">Contact 1</a></li>
                </ul>
              </li>
            </ul>
          </nav>
        </div>
        <!-- END MAIN NAVIGATION -->
      </div>
      <!-- END MAIN NAVIGATION WRAP -->
    </header>
    <!-- END HEADER -->

    <!-- START NOO WRAPPER -->
    <div class="noo-wrapper">

      <!-- START SEARCH BOX -->
      <section id="search-box" class="wrap search-box">
        <div class="gsearch">
          <div class="container">
            <!-- START GSEARCH INFO -->
            <div class="gsearch-info">
              <h4 class="gsearch-info-title">Find Your Place</h4>
              <div class="gsearch-info-content">Instantly find your desired place from your own idea of location, at any price <br> and other elements just by starting your search now</div>
            </div>
            <!-- END GSEARCH INFO -->

            <!-- START GSEARCH WRAP -->
            <div class="gsearch-wrap">
              <form class="gsearchform" method="get" role="search">
                <div class="gsearch-content">
                  <div class="gsearch-field">
                    <div class="form-group glocation">
                      <div class="label-select">
                        <select class="form-control">
                          <option>All Locations</option>
                          <option>New Jersey</option>
                          <option>New York</option>
                        </select>
                      </div>
                    </div>

                    <div class="form-group gsub-location">
                      <div class="label-select">
                        <select class="form-control">
                          <option>All Sub-locations</option>
                          <option>Central New York</option>
                          <option>GreenVille</option>
                          <option>Long Island</option>
                          <option>New York City</option>
                          <option>West Side</option>
                        </select>
                      </div>
                    </div>

                    <div class="form-group gstatus">
                      <div class="label-select">
                        <select class="form-control">
                        <option>All Status</option>
                        <option>Open house</option>
                        <option>Rent</option>
                        <option>Sale</option>
                        <option>Sold</option>
                      </select>
                      </div>
                    </div>

                    <div class="form-group gtype">
                      <div class="label-select">
                        <select class="form-control">
                          <option>All Type </option>
                          <option>Apartment</option>
                          <option>Co-op</option>
                          <option>Condo</option>
                          <option>Single Family Home</option>
                        </select>
                      </div>
                    </div>

                    <div class="form-group gbed">
                      <div class="label-select">
                        <select class="form-control">
                          <option>No. of Bedrooms</option>
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                          <option>5</option>
                        </select>
                      </div>
                    </div>

                    <div class="form-group gbath">
                      <div class="label-select">
                        <select class="form-control">
                          <option>No. of Bathrooms</option>
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                        </select>
                      </div>
                    </div>

                    <div class="form-group gprice">
                      <span class="gprice-label">Price</span>
                      <div class="gslider-range gprice-slider-range"></div>
                      <span class="gslider-range-value gprice-slider-range-value-min"></span>
                      <span class="gslider-range-value gprice-slider-range-value-max"></span>
                    </div>

                    <div class="form-group garea">
                      <span class="garea-label">Area</span>
                      <div class="gslider-range garea-slider-range"></div>
                      <span class="gslider-range-value garea-slider-range-value-min"></span>
                      <span class="gslider-range-value garea-slider-range-value-max"></span>
                    </div>
                  </div>

                  <div class="gsearch-action">
                    <div class="gsubmit">
                      <a class="btn btn-deault" href="#">Search Property</a>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <!-- END GSEARCH WRAP -->
          </div>
        </div>
      </section>
      <!-- END SEARCH BOX -->

      <!-- START RECENT AGENTS -->
      <section id="recent-agents-slider" class="wrap recent-agents recent-agents-slider">
        <div class="container">
          <div class="recent-agents-inner">
            <div class="recent-agents-title">
              <h3>MEET OUR AGENTS</h3>
            </div>
            <div class="recent-agents-content">
              <div class="caroufredsel-wrap row">
                <ul>
                  <li class="col-md-4 col-sm-6">
                    <!-- START AGENT 1 -->
                    <article class="hentry has-featured">
                      <div class="agent-featured">
                        <a class="content-thumb" href="agents-detail.html">
                          <img src="images/property/property1.jpg" alt="" />
                        </a>
                      </div>
                      <div class="agent-wrap">
                        <h2 class="agent-title"><a href="agents-detail.html" title="Adam Scooter">Adam Scooter</a></h2>
                        <div class="agent-excerpt">
                          <p>When people are looking for a real estate professional to consult, studies show they care most about loyalty and accountability....</p>
                        </div>
                        <div class="agent-social-wrap">
                          <div class="social-list agent-social">
                            <a href="#" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="#" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="#" title="Google +" target="_blank"><i class="fa fa-google-plus"></i></a>
                            <a href="#" title="Linkedin" target="_blank"><i class="fa fa-linkedin"></i></a>
                            <a href="#" title="Pinterest" target="_blank"><i class="fa fa-pinterest"></i></a>
                          </div>
                        </div>
                      </div>
                    </article>
                    <!-- END AGENT 1 -->
                  </li>

                  <li class="col-md-4 col-sm-6">
                    <!-- START AGENT 2 -->
                    <article class="hentry has-featured">
                      <div class="agent-featured">
                        <a class="content-thumb" href="agents-detail.html">
                          <img src="images/property/property1.jpg" alt="" />
                        </a>
                      </div>
                      <div class="agent-wrap">
                        <h2 class="agent-title"><a href="agents-detail.html" title="Thomas Adam Clayton">Thomas Adam Clayton</a></h2>
                        <div class="agent-excerpt">
                          <p>Recognized as the top selling broker in Lower Manhattan and among the best in New York City, Thomas Adam Clayton...</p>
                        </div>
                        <div class="agent-social-wrap">
                          <div class="social-list agent-social">
                            <a href="#" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="#" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="#" title="Google +" target="_blank"><i class="fa fa-google-plus"></i></a>
                            <a href="#" title="Linkedin" target="_blank"><i class="fa fa-linkedin"></i></a>
                            <a href="#" title="Pinterest" target="_blank"><i class="fa fa-pinterest"></i></a>
                          </div>
                        </div>
                      </div>
                    </article>
                    <!-- END AGENT 2 -->
                  </li>

                  <li class="col-md-4 col-sm-6">
                    <!-- START AGENT 3 -->
                    <article class="hentry has-featured">
                      <div class="agent-featured">
                        <a class="content-thumb" href="agents-detail.html">
                          <img src="images/property/property1.jpg" alt="" />
                        </a>
                      </div>
                      <div class="agent-wrap">
                        <h2 class="agent-title"><a href="agents-detail.html" title="Stacy Barron">Stacy Barron</a></h2>
                        <div class="agent-excerpt">
                          <p>Stacy is a long time resident and successful broker in the Lincoln Center area. Never far from home, sheis intimately acquainted...</p>
                        </div>
                        <div class="agent-social-wrap">
                          <div class="social-list agent-social">
                            <a href="#" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="#" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="#" title="Google +" target="_blank"><i class="fa fa-google-plus"></i></a>
                            <a href="#" title="Linkedin" target="_blank"><i class="fa fa-linkedin"></i></a>
                            <a href="#" title="Pinterest" target="_blank"><i class="fa fa-pinterest"></i></a>
                          </div>
                        </div>
                      </div>
                    </article>
                    <!-- END AGENT 3 -->
                  </li>

                  <li class="col-md-4 col-sm-6">
                    <!-- START AGENT 4 -->
                    <article class="hentry has-featured">
                      <div class="agent-featured">
                        <a class="content-thumb" href="agents-detail.html">
                          <img src="images/property/property1.jpg" alt="" />
                        </a>
                      </div>
                      <div class="agent-wrap">
                        <h2 class="agent-title"><a href="agents-detail.html" title="Michael Feng">Michael Feng</a></h2>
                        <div class="agent-excerpt">
                          <p>Michael Feng is a real estate agent, but his true goal is to be a resource for his clients. Since 2006,...</p>
                        </div>
                        <div class="agent-social-wrap">
                          <div class="social-list agent-social">
                            <a href="#" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="#" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="#" title="Google +" target="_blank"><i class="fa fa-google-plus"></i></a>
                            <a href="#" title="Linkedin" target="_blank"><i class="fa fa-linkedin"></i></a>
                            <a href="#" title="Pinterest" target="_blank"><i class="fa fa-pinterest"></i></a>
                          </div>
                        </div>
                      </div>
                    </article>
                    <!-- END AGENT 4 -->
                  </li>

                  <li class="col-md-4 col-sm-6">
                    <!-- START AGENT 5 -->
                    <article class="hentry has-featured">
                      <div class="agent-featured">
                        <a class="content-thumb" href="agents-detail.html">
                          <img src="images/property/property1.jpg" alt="" />
                        </a>
                      </div>
                      <div class="agent-wrap">
                        <h2 class="agent-title"><a href="agents-detail.html" title="John Doe">John Doe</a></h2>
                        <div class="agent-excerpt">
                          <p>John Doe, the founding partner of Elegran, started the company in 2007 in a unique way. He did this without...</p>
                        </div>
                        <div class="agent-social-wrap">
                          <div class="social-list agent-social">
                            <a href="#" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="#" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="#" title="Google +" target="_blank"><i class="fa fa-google-plus"></i></a>
                            <a href="#" title="Linkedin" target="_blank"><i class="fa fa-linkedin"></i></a>
                            <a href="#" title="Pinterest" target="_blank"><i class="fa fa-pinterest"></i></a>
                          </div>
                        </div>
                      </div>
                    </article>
                    <!-- END AGENT 5 -->
                  </li>
                </ul>
              </div>
              <a class="caroufredsel-prev" href="javascript:void(0)"></a>
              <a class="caroufredsel-next" href="javascript:void(0)"></a>
            </div>
          </div>
        </div>
      </section>
      <!-- END RECENT AGENTS -->

      <!-- START RECENT PROPERTIES -->
      <section class="wrap recent-properties" style="padding-top: 50px;">
        <div class="container">
          <div class="recent-properties-inner">
            <div class="properties grid">
              <div class="properties-header">
                <h1 class="page-title">Recent Properties</h1>
              </div>
              <div class="properties-content">
                <article class="hentry">
                  <div class="property-featured">
                    <a class="content-thumb" href="#">
                      <img src="images/property/property1.jpg" alt="">
                    </a>
                    <span class="property-category"><a href="#">Single Family Home</a>
                    </span>
                  </div>
                  <div class="property-wrap">
                    <h2 class="property-title">
                      <a href="property-details.html" title="Visalia, NJ 93277">Visalia, NJ 93277</a>
                    </h2>
                    <div class="property-excerpt">
                      <p>This 4 bedroom home sits on an oversized lot at the end of a cul-de-sac...</p>
                    </div>
                    <div class="property-summary">
                      <div class="property-detail">
                        <div class="size">
                          <span>1913 sqft</span>
                        </div>
                        <div class="bathrooms">
                          <span>2</span>
                        </div>
                        <div class="bedrooms">
                          <span>4</span>
                        </div>
                      </div>
                      <div class="property-info">
                        <div class="property-price">
                          <span>
                            <span class="amount">&#36;154,500</span>
                          </span>
                        </div>
                        <div class="property-action">
                          <a href="#">More Details</a>
                        </div>
                      </div>
                      <div class="property-info property-fullwidth-info">
                        <div class="property-price">
                          <span><span class="amount">$154,500</span> </span>
                        </div>
                        <div class="size"><span>1913 sqft</span></div>
                        <div class="bathrooms"><span>2</span></div>
                        <div class="bedrooms"><span>4</span></div>
                      </div>
                    </div>
                  </div>
                  <div class="property-action property-fullwidth-action">
                    <a href="#">More Details</a>
                  </div>
                </article>    
              </div>
            </div>
          </div>
        </div>  
      </section>
      <!-- END RECENT PROPERTIES -->

      <!-- START FEATURED PROPERTIES -->
      <section id="recent-properties-featured" class="wrap recent-properties recent-properties-featured">
        <div class="container">
          <div class="recent-properties-inner">
            <div class="recent-properties-title">
              <h3>Featured Properties</h3>
            </div>
            <div class="recent-properties-content">
              <div class="caroufredsel-wrap">
                <ul>
                  <li>
                    <article class="hentry has-featured">
                      <div class="property-featured">
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/featured-properties1.jpg" class="attachment-property-image" alt="" /> </a>
                        <span class="property-category"><a href="type-single-family-home.html">Single Family Home</a></span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title"><a href="property-details.html" title="Visalia, NJ 93277">Visalia, NJ 93277</a></h2>
                        <div class="property-excerpt">
                          <p>This 4 bedroom home sits on an oversized lot at the end of a cul-de-sac in an established neighborhood. It is in need of work however would make a great...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size"><span>1913 sqft</span>
                            </div>
                            <div class="bathrooms"><span>2</span>
                            </div>
                            <div class="bedrooms"><span>4</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;154,500</span> </span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details <i class="fa fa-arrow-circle-o-right"></i></a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </article>
                  </li>
                  <li>
                    <article class="hentry has-featured">
                      <div class="property-featured">
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/featured-properties1.jpg" class="attachment-property-image" alt="" /> </a>
                        <span class="property-category"><a href="type-single-family-home.html">Single Family Home</a></span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title"><a href="property-details.html" title="Single Family Residential, NJ">Single Family Residential, NJ</a></h2>
                        <div class="property-excerpt">
                          <p>Classic 60's ranch living. House has hardwood floors and hard coat plaster walls and ceilings in good condition. Intimate backyard for private gatherings. Full basement leaves plenty of room for...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size"><span>1118 sqft</span>
                            </div>
                            <div class="bathrooms"><span>2</span>
                            </div>
                            <div class="bedrooms"><span>3</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;299,000</span> </span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details <i class="fa fa-arrow-circle-o-right"></i></a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </article>
                  </li>
                  <li>
                    <article class="hentry has-featured">
                      <div class="property-featured">
                        <a class="content-thumb" href="property-details.html">
                          <img src="images/property/featured-properties1.jpg" class="attachment-property-image" alt="" /> </a>
                        <span class="property-category"><a href="type-apartment.html">Apartment</a></span>
                      </div>
                      <div class="property-wrap">
                        <h2 class="property-title"><a href="property-details.html" title="Peter Cooper Village">Peter Cooper Village</a></h2>
                        <div class="property-excerpt">
                          <p>Peter Cooper Village/ Stuyvesant Town provides an unbeatable combination of city energy and community tranquility, providing insulation from the city that surrounds it, yet situated next to Manhattan's most dynamic...</p>
                        </div>
                        <div class="property-summary">
                          <div class="property-detail">
                            <div class="size"><span>1304 sqft</span>
                            </div>
                            <div class="bathrooms"><span>2</span>
                            </div>
                            <div class="bedrooms"><span>3</span>
                            </div>
                          </div>
                          <div class="property-info">
                            <div class="property-price">
                              <span><span class="amount">&#36;5,109</span> /month</span>
                            </div>
                            <div class="property-action">
                              <a href="property-details.html">More Details <i class="fa fa-arrow-circle-o-right"></i></a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </article>
                  </li>
                </ul>
              </div>
              <a class="caroufredsel-prev" href="#"></a>
              <a class="caroufredsel-next" href="#"></a>
            </div>
          </div>
        </div>
      </section>
      <!-- END FEATURED PROPERTIES -->

      <!-- START OUR SERVICES -->
      <section id="our-sevices" class="wrap our-sevices">
        <div class="container">
          <div class="parallax">
            <div class="bg parallax-bg"></div>
            <div class="overlay"></div>
            <div class="our-sevices-content">
              <div class="row clearfix">
              
                <div class="col-xs-12 col-sm-4 our-sevices-col">
                  <span class="service-icon">
                    <i class="fa fa-home"></i>
                  </span>
                  <hr class="noo-gap">
                  <div class="text-block">
                    <h5>Hottest Property List</h5>
                    <p>Wherever you are and you want to go, we provide you extremely hot and continuously<br>updated property list.</p>
                    <p><a class="icon-right" href="#">See latest list<i class="fa fa-arrow-circle-o-right"></i></a></p>
                  </div>
                </div>

                <div class="col-xs-12 col-sm-4 our-sevices-col">
                  <span  class="service-icon">
                    <i class="fa fa-thumbs-o-up"></i>
                  </span>
                  <hr class="noo-gap">
                  <div class="text-block">
                    <h5>Best Price In Market</h5>
                    <p>Wherever you are and you want to go, we provide you extremely hot and continuously
                    <br>updated property list.</p>
                    <p><a class="icon-right" href="#">See latest list<i class="fa fa-arrow-circle-o-right"></i></a>
                    </p>
                  </div>
                </div>

                <div class="col-xs-12 col-sm-4 our-sevices-col">
                  <span class="service-icon">
                    <i class="fa fa-star"></i>
                  </span>
                  <hr class="noo-gap">
                  <div class="text-block">
                    <h5>Guaranteed Service</h5>
                    <p>Wherever you are and you want to go, we provide you extremely hot and continuously
                      <br>updated property list.</p>
                    <p>
                      <a class="icon-right" href="#">See latest list<i class="fa fa-arrow-circle-o-right"></i></a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- END OUR SERVICES -->

      <!-- START CALL TO ACTION -->
      <section id="call-to-action" class="wrap call-to-action">
        <div class="container">
          <div class="parallax">
            <div class="bg parallax-bg"></div>
            <div class="overlay"></div>
            <div class="call-to-action-content">
              <div class="row clearfix">
                <div class="col-xs-12 col-sm-6 item-col">
                  <div class="text-block">
                    <h3>ONLY IN JULY</h3>
                    <p>Be the first to get our hottest unlisted property list!</p>
                  </div>
                </div>
                <div class="col-xs-12 col-sm-6 item-col">
                  <div class="call-to-action-btn">
                    <a href="#" class="btn" role="button">GET IT NOW</a>
                  </div>
                </div>
              </div>            
            </div>
          </div>
        </div>
      </section>
      <!-- END CALL TO ACTION -->

      <!-- START TESTIMONIAL -->
      <section id="testimonial" class="wrap testimonial">
        <div class="container">
          <div class="testimonial-inner">
            <div class="section-title">
              <h3>Testimonial</h3>
            </div>
            <div class="testimonial-content">
              <div class="carousel slide" id="carousel-testimonial">
                <ol class="carousel-indicators">
                  <li data-target="#carousel-testimonial" data-slide-to="0" class="active"></li>
                  <li data-target="#carousel-testimonial" data-slide-to="1"></li>
                  <li data-target="#carousel-testimonial" data-slide-to="2"></li>
                  <li data-target="#carousel-testimonial" data-slide-to="3"></li>
                </ol>
                <div class="carousel-inner">
                  <!-- START ITEM 1 -->
                  <div class="item active">
                    <div class="slide-content">
                      <div class="testimonial-desc">“I found my current apartment on Citilights with extraordinary help from them and totally satisfied with the choice I made. All I had to do was to tell what I was looking for and I got back property suggestions nearly exact to my imagination. Among those, I finally chose mine now then completed procedure at ease. Highly recommend Citilights for your home search.”</div>
                      <div class="our-customer-info">
                        <div class="avatar">
                          <a href="#"><img src="images/other/customer1.png" alt=""></a>
                        </div>
                        <div class="custom-desc">
                          <h4>Dave Softel</h4>
                          <p>Happy Buyer of June</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- END ITEM 1 -->

                  <!-- START ITEM 2 -->
                  <div class="item">
                    <div class="slide-content">
                      <div class="testimonial-desc">“I found my current apartment on Citilights with extraordinary help from them and totally satisfied with the choice I made. All I had to do was to tell what I was looking for and I got back property suggestions nearly exact to my imagination. Among those, I finally chose mine now then completed procedure at ease. Highly recommend Citilights for your home search.”</div>
                      <div class="our-customer-info">
                        <div class="avatar">
                          <a href="#"><img src="images/other/customer1.png" alt=""></a>
                        </div>
                        <div class="custom-desc">
                          <h4>Dave Softel</h4>
                          <p>Happy Buyer of June</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- END ITEM 2 -->

                  <!-- START ITEM 3 -->
                  <div class="item">
                    <div class="slide-content">
                      <div class="testimonial-desc">“I found my current apartment on Citilights with extraordinary help from them and totally satisfied with the choice I made. All I had to do was to tell what I was looking for and I got back property suggestions nearly exact to my imagination. Among those, I finally chose mine now then completed procedure at ease. Highly recommend Citilights for your home search.”</div>
                      <div class="our-customer-info">
                        <div class="avatar">
                          <a href="#"><img src="images/other/customer1.png" alt=""></a>
                        </div>
                        <div class="custom-desc">
                          <h4>Dave Softel</h4>
                          <p>Happy Buyer of June</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- END ITEM 3 -->

                  <!-- START ITEM 4 -->
                  <div class="item">
                    <div class="slide-content">
                      <div class="testimonial-desc">“I found my current apartment on Citilights with extraordinary help from them and totally satisfied with the choice I made. All I had to do was to tell what I was looking for and I got back property suggestions nearly exact to my imagination. Among those, I finally chose mine now then completed procedure at ease. Highly recommend Citilights for your home search.”</div>
                      <div class="our-customer-info">
                        <div class="avatar">
                          <a href="#"><img src="images/other/customer1.png" alt=""></a>
                        </div>
                        <div class="custom-desc">
                          <h4>Dave Softel</h4>
                          <p>Happy Buyer of June</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- END ITEM 4 -->
                </div>
              </div>            
            </div>
          </div>
            
        </div>
      </section>
      <!-- END TESTIMONIAL -->

      <!-- START OUR PARTNERS -->
      <section id="our-partners" class="wrap our-partners">
        <div class="container">
          <div class="our-partners-inner">
            <div class="row">
              <div class="col-sm-6 col-md-2 item-col">
                <a href="http://themeforest.net/" target="_blank">
                  <img class="item-image" src="images/partner/partner1.png" alt="">
                </a>
              </div>
              <div class="col-sm-6 col-md-2 item-col">
                <a href="http://codecanyon.net/" target="_blank">
                  <img class="item-image" src="images/partner/partner2.png" alt="">
                </a>
              </div>
              <div class="col-sm-6 col-md-2 item-col">
                <a href="http://videohive.net/" target="_blank">
                  <img class="item-image" src="images/partner/partner3.png" alt="">
                </a>
              </div>
              <div class="col-sm-6 col-md-2 item-col">
                <a href="http://audiojungle.net/" target="_blank">
                  <img class="item-image" src="images/partner/partner4.png" alt="">
                </a>
              </div>
              <div class="col-sm-6 col-md-2 item-col">
                <a href="http://photodune.net/" target="_blank">
                  <img class="item-image" src="images/partner/partner5.png" alt="">
                </a>
              </div>
              <div class="col-sm-6 col-md-2 item-col">
                <a href="http://activeden.net/" target="_blank">
                  <img class="item-image" src="images/partner/partner6.png" alt="">
                </a>
              </div>
            </div>
          </div>      
        </div>
      </section>
      <!-- END OUR PARTNERS -->
    </div>
    <!-- END NOO WRAPPER -->

    <!-- START FOOTER -->
    <footer class="footer">
      <!-- START FOOTER NAVIGATION -->
      <div class="footer-nav">
        <div class="container">
          <div class="row">
            <!-- START FOOTER ABOUT US -->
            <div class="col-xs-12 col-sm-6 col-md-3 footer-nav-col">
              <div class="ft-about-us">
                <h4 class="ft-col-title">CitiLights</h4>
                <div class="text-block">
                  <p>CitiLights brings wide range of choice, steadily updated property list and market trend for you to figure out your right decision.</p>
                  <p>You are now at right place for your real estate research.</p>
                </div>
              </div>
            </div>
            <!-- END ABOUT US -->

            <!-- START FOOTER FEATURED PROPERTIES -->
            <div class="col-xs-12 col-sm-6 col-md-3 footer-nav-col">
              <div class="ft-featured-properties">
                <h4 class="ft-col-title">Featued Property</h4>
                <div class="featured-property">
                  <ul>
                    <li>
                      <div class="featured-image">
                        <a href="property-details.html"><img src="images/property/property1.jpg" alt=""></a>
                      </div>
                      <div class="featured-decs">
                        <span class="featured-status"><a href="#"></a></span>
                        <h4 class="featured-title"><a href="property-details.html" title="Fresno, CA93722">Fresno, CA93722</a></h4>
                      </div>
                    </li>
                    <li>
                      <div class="featured-image">
                        <a href="property-details.html"><img src="images/property/property1.jpg" alt=""></a>
                      </div>
                      <div class="featured-decs">
                        <span class="featured-status"><a href="#">For Rent</a></span>
                        <h4 class="featured-title"><a href="property-details.html" title="AVA High Line">AVA High Line</a></h4>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- END FOOTER FEATURED PROPERTIES -->

            <!-- START FOOTER USEFUL LINKS -->
            <div class="col-xs-12 col-sm-6 col-md-3 footer-nav-col">
              <div class="ft-useful-links">
                <h4 class="ft-col-title">Useful links</h4>
                <nav class="useful-links-menu" role="navigation">
                  <ul>
                    <li class="menu-item"><a href="#">Terms of Use</a></li>
                    <li class="menu-item"><a href="#">Privacy Policy</a></li>
                    <li class="menu-item"><a href="#">Contact Support</a></li>
                    <li class="menu-item"><a href="#">Knowledgebase</a></li>
                    <li class="menu-item"><a href="#">Careers</a></li>
                    <li class="menu-item"><a href="#">FAQs</a></li>
                  </ul>
                </nav>
              </div>
            </div>
            <!-- END FOOTERUSEFUL LINKS  -->

            <!-- START FOOTER CONTACT INFO -->
            <div class="col-xs-12 col-sm-6 col-md-3 footer-nav-col">
              <div class="ft-contact-info">
                <h4 class="ft-col-title">Contact info</h4>
                  <ul class="detail-contact-info">
                    <li><i class="fa fa-map-marker"></i>&nbsp;376 Baker Street, New York</li>
                    <li><i class="fa fa-phone"></i>&nbsp;(+01)-486-2857</li>
                    <li><i class="fa fa-envelope-o"></i>&nbsp;<a href="mailto:info@citilights.com">info@citilights.com</a></li>
                  </ul>
              </div>
            </div>
            <!-- END FOOTER CONTACT INFO -->
          </div>
        </div>
      </div>
      <!-- END FOOTER NAVIGATION -->

      <!-- START COPYRIGHT -->
      <div class="copyright">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-sm-6 text-block">
              &copy; 2014 CitiLights. All Rights Reserved.
              <br />
              <span>Designed by <a title="Visit Nootheme.com!" href="http://www.nootheme.com/" target="_blank">NooTheme.com</a>.</span>
              <br>
            </div>
            <div class="col-xs-12 col-sm-6 logo-block">
              <div class="logo-image">
                <a href="index.html"><img src="images/logo/logo-footer.png" alt="CitiLights"></a>
              </div>
            </div>
          </div>          
        </div>
       
        <!-- START BACK TO TOP -->
        <div id="back-to-top" class="back-to-top">
          <i class="fa fa-angle-up"></i>
        </div>
        <!-- END BACK TO TOP -->
      </div>
      <!-- END COPYRIGHT -->
    </footer>
    <!-- END FOOTER -->
  </div>
  <!-- END SITE -->

  <!-- JQUERY PLUGIN -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
  <script type="text/javascript" src="js/SmoothScroll.js"></script>
  <script type="text/javascript" src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
  <script type="text/javascript" src="js/jquery.touchSwipe.min.js"></script>
  <script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
  <script type="text/javascript" src="js/jquery.nouislider.all.min.js"></script>

  <!-- THEME SCRIPT -->
  <script type="text/javascript" src="js/property-slider.js"></script>
  <script type="text/javascript" src="js/script.js"></script>
  
</body>

</html>